const strings = require('../strings');
const utils = require('../utils');

/** Answer Intent Handler
 * The Answer Handler is responsible for handling any 'stop' or 'cancel' intents. It says an error message and resets the game state.
 * Handler to be invoked when a player answers a question
 */

module.exports = {
    canHandle(handlerInput) {
      return handlerInput.requestEnvelope.request.type === 'IntentRequest'
        && (handlerInput.requestEnvelope.request.intent.name === 'AnswerIntent')
    },
    handle(handlerInput) {
        const cats = ['SONG', 'MOVIE', 'PHRASES'];
        const slots = handlerInput.requestEnvelope.request.intent.slots.answer;
        const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        const round = sessionAttributes.round;
        const cat = cats[round - 1]; //1 - Song, 2 - Movie, 3 - Phrases
        const qn = utils.getId(slots).qn; //cat's qn (1, 2, 3)
        const ans = utils.getId(slots).id; //player's ans ('A')
        const player = sessionAttributes.currentPlayer - 1; //0 or 1
        const numPlayers = sessionAttributes.player; //1 or 2
        const count = sessionAttributes.currentQuestion; //increments - if currently is qn 1 then is player1, qn 2 then is player2
        let questions = sessionAttributes.questions; //randomised array of qn numbers to be asked
        let points = sessionAttributes.score;
        let speechText = utils.checkAnswer(cat, qn, ans);

        // add points
        points[player] += utils[cat][qn][ans];

        //check if end game
        if (round === 3) {
            speechText = utils.endGame(numPlayers, points);
            sessionAttributes.state = 'ENDED';
        } else {
            if (numPlayers === 2) { //duo
                speechText += strings['SCORE'] + points[player];
                if (player === 1) { //player2:
                    speechText += strings['PLAYER_1'] + strings['AGAIN'] + strings['QUESTION_' + (sessionAttributes.currentQuestion).toString()] + strings.cat[questions[count]]
                } else { //player1
                    speechText += strings['PLAYER_2'] + strings['QUESTION_' + (sessionAttributes.currentQuestion).toString()] + strings.cat[questions[count]]
                }
                sessionAttributes.player = utils.resetPlayer(player);
            } else { //solo
                speechText += points[player] + strings['QUESTION_' + (sessionAttributes.currentQuestion + 2).toString()] + strings.cat[questions[count]];
            }
        }

        // update sessionAttributes
        sessionAttributes.currentQuestion += 1;
        sessionAttributes.lastUtterance = speechText;
        handlerInput.attributesManager.setSessionAttributes(sessionAttributes);

        return handlerInput.responseBuilder
        .speak(speechText)
        .reprompt(strings.ANSWER_REPROMPT)
        .getResponse();
    }
  };